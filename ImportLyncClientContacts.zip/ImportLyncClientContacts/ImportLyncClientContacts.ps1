<#
The sample scripts are not supported under any Microsoft standard support 
program or service. The sample scripts are provided AS IS without warranty  
of any kind. Microsoft further disclaims all implied warranties including,  
without limitation, any implied warranties of merchantability or of fitness for 
a particular purpose. The entire risk arising out of the use or performance of  
the sample scripts and documentation remains with you. In no event shall 
Microsoft, its authors, or anyone else involved in the creation, production, or 
delivery of the scripts be liable for any damages whatsoever (including, 
without limitation, damages for loss of business profits, business interruption, 
loss of business information, or other pecuniary loss) arising out of the use 
of or inability to use the sample scripts or documentation, even if Microsoft 
has been advised of the possibility of such damages.
#>

#requires -Version 2

#Import Localized Data
Import-LocalizedData -BindingVariable Messages
#Import Microsoft.Lync.Model from default folder
Try
{
	Import-Module "C:\Windows\assembly\GAC_MSIL\Microsoft.Lync.Model\4.0.0.0__31bf3856ad364e35\Microsoft.Lync.Model.dll"
}
Catch
{
	$errorMsg = $Messages.InstallLyncRuntime
	Write-Error $errorMsg
}

#Get Lync client object
if ($?) {
	$lyncClient = [Microsoft.Lync.Model.LyncClient]::GetClient()
}

Function New-OSCPSCustomErrorRecord
{
	#This function is used to create a PowerShell ErrorRecord
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory=$true,Position=1)][String]$ExceptionString,
		[Parameter(Mandatory=$true,Position=2)][String]$ErrorID,
		[Parameter(Mandatory=$true,Position=3)][System.Management.Automation.ErrorCategory]$ErrorCategory,
		[Parameter(Mandatory=$true,Position=4)][PSObject]$TargetObject
	)
	Process
	{
		$exception = New-Object System.Management.Automation.RuntimeException($ExceptionString)
		$customError = New-Object System.Management.Automation.ErrorRecord($exception,$ErrorID,$ErrorCategory,$TargetObject)
		return $customError
	}
}

Function Out-OSCLyncContacts
{
	#.EXTERNALHELP Out-OSCLyncContacts-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$FilePath,			
		[Parameter(Mandatory=$true,Position=2)]
		[string[]]$DistributionGroup,
		[Parameter(Mandatory=$false,Position=3)]
		[hashtable]$CustomGroupContact,		
		[Parameter(Mandatory=$false,Position=4)]
		[switch]$Overwrite,
		[Parameter(Mandatory=$false,Position=5)]
		[int]$SigninTimeout=10
	)
	Process
	{
		if ($FilePath.SubString($FilePath.Length - 3,3) -notmatch "xml|csv") {
			$errorMsg = $Messages.OutputFileWithWrongExtenstion
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		if ($lyncClient -ne $null) {
			#Wait Lync client sign in
			while ($lyncClient.State -ne [Microsoft.Lync.Model.ClientState]::SignedIn) {
				$verboseMsg = $Messages.WaitSignin
				$verboseMsg = $verboseMsg -replace "Placeholder01",$SigninTimeout
				$pscmdlet.WriteVerbose($verboseMsg)
				Start-Sleep -Seconds $SigninTimeout
				break
			}
			#Quit function after time out if Lync client still not sign in 
			if ($lyncClient.State -ne [Microsoft.Lync.Model.ClientState]::SignedIn) {
				$errorMsg = $Messages.SigninRequired
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)
			}
			$targetContacts = @()
			#Get Contact Manager
            		$contactManager = $lyncClient.ContactManager
			#Get distribution group by using searching
			foreach ($dg in $DistributionGroup) {
				$searchResults = $contactManager.EndSearch($contactManager.BeginSearch($dg,$null,$null))
				if ($searchResults.Groups.Count -eq 0) {
					$warningMsg = $Messages.CannotFindDG
					$warningMsg = $warningMsg -replace "Placeholder01",$dg
					$pscmdlet.WriteWarning($warningMsg)				
				} else {
					foreach ($distributionGroup in $searchResults.Groups) {
						$targetContact = New-Object System.Management.Automation.PSObject
						$verboseMsg = $Messages.FoundDistributionGroup
						$verboseMsg = $verboseMsg -replace "Placeholder01",$distributionGroup.Name
						$pscmdlet.WriteVerbose($verboseMsg)
						$targetContact | Add-Member -MemberType NoteProperty -Name GroupName -Value $distributionGroup.Name
						$targetContact | Add-Member -MemberType NoteProperty -Name GroupType -Value "DistributionGroup"
						$targetContact | Add-Member -MemberType NoteProperty -Name Overwrite -Value "N/A"
						$targetContact | Add-Member -MemberType NoteProperty -Name Contacts -Value $distributionGroup.EmailAddress
						$targetContacts += $targetContact
					}
				}
			}
			#Prepare custom groups
			if ($CustomGroupContact -ne $null) {
				foreach ($contactGroupName in $CustomGroupContact.Keys.GetEnumerator()) {
					$targetContact = New-Object System.Management.Automation.PSObject
					if (($targetContacts | ?{$_.GroupName -eq $contactGroupName}) -ne $null) {
						$warningMsg = $Messages.ConflictWithDG
						$warningMsg = $warningMsg -replace "Placeholder01",$contactGroupName
						$pscmdlet.WriteWarning($warningMsg)
					} else {
						$verboseMsg = $Messages.PrepareCustomGroup
						$verboseMsg = $verboseMsg -replace "Placeholder01",$contactGroupName
						$pscmdlet.WriteVerbose($verboseMsg)
						$specificContacts = $CustomGroupContact[$contactGroupName].Split(";")
						$tContacts = @()
						foreach ($specificContact in $specificContacts) {
							$contactSearchResults = $contactManager.EndSearch($contactManager.BeginSearch($specificContact,$null,$null))
							if ($contactSearchResults.Contacts.Count -ne 0) {
								foreach ($contactSearchResult in $contactSearchResults) {
									foreach ($tContact in $contactSearchResult.Contacts) {
										$tContacts += $tContact.Uri
									}	
								}
							} else {
								$warningMsg = $Messages.CannotFindContact
								$warningMsg = $warningMsg -replace "Placeholder01",$specificContact
								$pscmdlet.WriteWarning($warningMsg)							
							}
						}
						$tContacts = $tContacts -join ";"
						$targetContact | Add-Member -MemberType NoteProperty -Name GroupName -Value $contactGroupName
						$targetContact | Add-Member -MemberType NoteProperty -Name GroupType -Value "CustomGroup"
						$targetContact | Add-Member -MemberType NoteProperty -Name Overwrite -Value $Overwrite
						$targetContact | Add-Member -MemberType NoteProperty -Name Contacts -Value $tContacts
						$targetContacts += $targetContact
					}
				}
			}
			#Export the result
			Switch ($FilePath.SubString($FilePath.Length - 3,3)) {
				"xml" {
					$targetContacts | ConvertTo-Xml -NoTypeInformation | Export-Clixml -Path $FilePath -Force
				}
				"csv" {
					$targetContacts | Export-Csv -Path $FilePath -NoTypeInformation -Force
				}
			}
		}
	}
}

Function Import-OSCLyncContacts
{
	#.EXTERNALHELP Import-OSCLyncContacts-Help.xml
	
	[CmdletBinding()]
	Param
	(
		#Define parameters
		[Parameter(Mandatory=$true,Position=1)]
		[string]$FilePath,
		[Parameter(Mandatory=$false,Position=2)]
		[int]$SigninTimeout=10
	)
	Process
	{
		#Check input file and prepare contact groups for further processing
		if ((Test-Path -Path $FilePath -PathType Leaf)) {
			$fileExt = $FilePath.SubString($FilePath.Length - 3,3)
			Switch ($fileExt) {
				"csv" {
					if ((Get-Content -Path $FilePath -TotalCount 1) -eq "`"GroupName`",`"GroupType`",`"Overwrite`",`"Contacts`"") {
						$contactGroups = Import-Csv $FilePath
					} else {
						$errorMsg = $Messages.WrongColumnHeaders
						$customError = New-OSCPSCustomErrorRecord `
						-ExceptionString $errorMsg `
						-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
						$pscmdlet.ThrowTerminatingError($customError)
					}
				}
				"xml" {
					$contactGroups = @()
					$xmlDoc = Import-Clixml -Path $FilePath
					$groupProperties = $xmlDoc.SelectNodes("Objects/Object/Property")
					foreach ($groupProperty in $groupProperties) {
						Switch ($groupProperty.Name) {
							"GroupName" {
								$contactGroup = New-Object System.Management.Automation.PSObject
								$contactGroup | Add-Member -MemberType NoteProperty -Name "GroupName" -Value $groupProperty."#text"								
							}
							"GroupType" {
								$contactGroup | Add-Member -MemberType NoteProperty -Name "GroupType" -Value $groupProperty."#text"							
							}
							"Overwrite" {
								$contactGroup | Add-Member -MemberType NoteProperty -Name "Overwrite" -Value $groupProperty."#text"							
							}
							"Contacts" {
								$contactGroup | Add-Member -MemberType NoteProperty -Name "Contacts" -Value $groupProperty."#text"
								$contactGroups += $contactGroup
							}
						}
					}
				}
			}
		} else {
			$errorMsg = $Messages.CannotFindFile
			$errorMsg = $errorMsg -replace "Placeholder01",$FilePath
			$customError = New-OSCPSCustomErrorRecord `
			-ExceptionString $errorMsg `
			-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
			$pscmdlet.ThrowTerminatingError($customError)
		}
		if ($lyncClient -ne $null) {
			#Wait Lync client sign in
			while ($lyncClient.State -ne [Microsoft.Lync.Model.ClientState]::SignedIn) {
				$verboseMsg = $Messages.WaitSignin
				$verboseMsg = $verboseMsg -replace "Placeholder01",$SigninTimeout
				$pscmdlet.WriteVerbose($verboseMsg)
				Start-Sleep -Seconds $SigninTimeout
				break
			}
			#Quit function after time out if Lync client still not sign in 
			if ($lyncClient.State -ne [Microsoft.Lync.Model.ClientState]::SignedIn) {
				$errorMsg = $Messages.SigninRequired
				$customError = New-OSCPSCustomErrorRecord `
				-ExceptionString $errorMsg `
				-ErrorCategory NotSpecified -ErrorID 1 -TargetObject $pscmdlet
				$pscmdlet.ThrowTerminatingError($customError)				
			} else {
				#Get current user SIP address
				$currentUser = $lyncClient.Uri
				#Get Contact Manager
                		$contactManager = $lyncClient.ContactManager
                		#Iterate over the contact groups
				foreach ($contactGroup in $contactGroups) {
					#Try to get contact
					$groupContacts = $contactGroup.Contacts
					if ([System.String]::IsNullOrEmpty($groupContacts)) {
						$warningMsg = $Messages.ZeroContact
						$pscmdlet.WriteWarning($warningMsg)	
						break
					}					
					#Try to get group from contact list
					$groupObject = $null
					$groupName = $contactGroup.GroupName
					$overWriteGroupMember = $contactGroup.Overwrite
					$existingGroup = $contactManager.Groups.TryGetGroup($groupName,[ref]$groupObject)
					#If a distribution group exists, move to next contact group.
					#If a custom group exists, display a warning messages or remove existing contacts.
					#If group does not exist in the contact list, find and add it to the contact list.
					if ($existingGroup) {
						$warningMsg = $Messages.GroupExists
						$warningMsg = $warningMsg -replace "Placeholder01",$groupName
						$pscmdlet.WriteWarning($warningMsg)						
						Switch ($groupObject.Type) {
							"DistributionGroup" {
								break
							}
							"CustomGroup" {
								#If the display name of a distribution group is occupied by a custom group
								#in the contact list, move to next contact group.
								if ($contactGroup.GroupType -eq "DistributionGroup") {break}
								#Check the Overwrite parameter
								if ($overWriteGroupMember -ne "True") {
									$warningMsg = $Messages.AppendGroupMember
									$pscmdlet.WriteWarning($warningMsg)
								} else {
									$warningMsg = $Messages.OverwriteWarning
									$pscmdlet.WriteWarning($warningMsg)
									foreach ($contact in $groupObject) {
										$groupObject.EndRemoveContact($groupObject.BeginRemoveContact($contact,$null,$null))
									}
								}
							}
						}
					} else {
						Switch ($contactGroup.GroupType) {
							"DistributionGroup" {
								#Verify the existence of distribution group by using searching
								$searchResults = $contactManager.EndSearch($contactManager.BeginSearch($groupContacts,$null,$null))
								if ($searchResults.Groups.Count -ne 0) {
    								#Add distribution groups
    								foreach ($distributionGroup in $searchResults.Groups) {
    									$verboseMsg = $Messages.AddDistributionGroup
    									$verboseMsg = $verboseMsg -replace "Placeholder01",$distributionGroup.Name
    									$pscmdlet.WriteVerbose($verboseMsg)
    									Try
    									{											
    										$contactManager.EndAddGroup($contactManager.BeginAddGroup($distributionGroup,$null,$null))
    									}
    									Catch
    									{
    										$pscmdlet.WriteError($Error[0])
    									}
    								}
    							} else {
									$warningMsg = $Messages.CannotFindDG
									$warningMsg = $warningMsg -replace "Placeholder01",$groupContacts
									$pscmdlet.WriteWarning($warningMsg)
								}							
							}
							"CustomGroup" {
								#Try to add custom group
								$verboseMsg = $Messages.AddCustomGroup
								$verboseMsg = $verboseMsg -replace "Placeholder01",$groupName
								$pscmdlet.WriteVerbose($verboseMsg)
								Try
								{
									$contactManager.EndAddGroup($contactManager.BeginAddGroup($groupName,$null,$null))
								}
								Catch
								{
									$pscmdlet.WriteError($Error[0])
								}
								while (-not $contactManager.Groups.TryGetGroup($groupName,[ref]$groupObject)) {
									Start-Sleep -Milliseconds 500
								}
							}
						}
					}
					#Add members to custom group
					if ($groupObject.Type -eq "CustomGroup") {
						#If the display name of a distribution group is occupied by a custom group
						#in the contact list, move to next contact group.
						if ($contactGroup.GroupType -eq "DistributionGroup") {break}					
						$customGroupContacts = $groupContacts.Split(";")
						foreach ($customGroupContact in $customGroupContacts) {
							#Search each contact
							$searchResults = $contactManager.EndSearch($contactManager.BeginSearch($customGroupContact,$null,$null))
							if ($searchResults.Contacts.Count -ne 0) {
								foreach ($contactObject in $searchResults.Contacts) {
									#Skip contact list owner for avoiding error
									if ($contactObject.Uri -eq $currentUser) {
										$verboseMsg = $Messages.SkipContactListOwner
										$pscmdlet.WriteVerbose($verboseMsg)
										break
									}
									#Begin to add contact
									$outContact = $null
									$existingContactObject = $groupObject.TryGetContact($contactObject.Uri,[ref]$outContact)
									if (-not $existingContactObject) {
										$verboseMsg = $Messages.AddContact
										$verboseMsg = $verboseMsg -replace "Placeholder01",$contactObject.Uri
										$verboseMsg = $verboseMsg -replace "Placeholder02",$groupName
										$pscmdlet.WriteVerbose($verboseMsg)
										$groupObject.EndAddContact($groupObject.BeginAddContact($contactObject,$null,$null))
									} else {
										$verboseMsg = $Messages.ContactExists
										$verboseMsg = $verboseMsg -replace "Placeholder01",$contactObject.Uri
										$pscmdlet.WriteVerbose($verboseMsg)													
									}
								}
							} else {
								$warningMsg = $Messages.CannotFindContact
								$warningMsg = $warningMsg -replace "Placeholder01",$customGroupContact
								$pscmdlet.WriteWarning($warningMsg)
							}
						}
					}
				}
			}
		}
	}
}

